
             <?php
             include('connect.php');
             $sql_footer = "select * from manage_website"; 
             $result_footer = $conn->query($sql_footer);
             $row_footer = mysqli_fetch_array($result_footer);
             ?>
             <?php //echo $row_footer['footer'];?>
            <footer class="footer" style="  position: fixed;left: 0;bottom: 0;width: 100%;text-align: center;"> © 2019 All rights reserved:<a href="https://www.youtube.com/channel/UCnTEh3OFRS1wP0-Wqm2D-rA?sub_confirmation=1"> Nikhil Bhalerao ||  +919423979339    || ndbhalerao91@gmail.com</a>
  <!-- before changing this footer you must have authors permission -->
</footer> 
            
        </div>
   
    </div>
   
    <script src="js/lib/jquery/jquery.min.js"></script>
    
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    
    <script src="js/jquery.slimscroll.js"></script>
   
    <script src="js/sidebarmenu.js"></script>
  
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>


 <script src="js/lib/sweetalert/sweetalert.min.js"></script>
 
    <script src="js/lib/sweetalert/sweetalert.init.js"></script>

    <script src="js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="js/lib/weather/weather-init.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>


  
 
    <script src="js/custom.min.js"></script>


     <script src="js/lib/datatables/datatables.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script src="js/lib/datatables/datatables-init.js"></script>

     <script src="js/lib/calendar-2/moment.latest.min.js"></script>
    
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    
    <script src="js/lib/calendar-2/prism.min.js"></script>
    
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
   
    <script src="js/lib/calendar-2/pignose.init.js"></script>

 
    <script src="js/lib/html5-editor/wysihtml5-0.3.0.js"></script>
    <script src="js/lib/html5-editor/bootstrap-wysihtml5.js"></script>
    <script src="js/lib/html5-editor/wysihtml5-init.js"></script>
</body>

</html>
<script>
function alphaOnly(event) {
  var key = event.keyCode;
  return ((key >= 65 && key <= 90) || key == 8);
};
                                        </script>
                                        <script>
    
    function isNumber(evt) {
        var iKeyCode = (evt.which) ? evt.which : evt.keyCode
        if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
            return false;

        return true;
    }    
</script>

